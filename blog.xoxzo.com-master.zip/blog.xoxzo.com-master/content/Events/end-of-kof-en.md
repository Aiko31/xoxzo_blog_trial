Title: Participating KOF-Kansai Open Source Forum
Date: 2016-11-14 11:00 
Slug: kof-2016-report
Lang: en
Modified: 2012-11-14 11:00
Tags: kof; osaka; exhibition;
Author: Aiko Yokoyama
Summary: We participated in the KOF 2016 and this is what we think

We are happy to announce that our KOF (Kansai Open Forum held on Nov 11 & 12 in
Osaka, Japan) display ended successful.

![KOF関西バナー]({filename}/images/kof.jpg)

We had many visitor to our booth and were shown demonstration of ‘Sending
SMS/Calls from the Internet’. Some immediately went thinking how to integrate
the API into their own applications, while others tried to work out how this
could work or just simply enjoy what our API does.

![KOF関西にてXoxzoのブース]({filename}/images/kof-booth.jpg)

![KOF関西にてXoxzoの野中がLTを行う]({filename}/images/kof-akira-lt.jpg)

It was a great experience for us meeting our potential users, not only spreading
our technology but also to know what further solutions they are seeking for,
which would raise us to the next step, for further developments.

We are for sure to come back to the next exhibition to meet more people, with
our aim to empower the world.
