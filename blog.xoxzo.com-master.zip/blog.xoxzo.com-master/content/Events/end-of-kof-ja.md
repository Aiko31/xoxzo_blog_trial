Title: KOF-関西オープンフォーラムを終えて
Date: 2016-11-14 11:00 
Slug: kof-2016-report
Lang: ja
Modified: 2012-11-14 11:00
Tags: kof; 大阪; 出展;
Author: Aiko Yokoyama
Summary: KOF関西に参加してその感想を書く

![KOF関西バナー]({filename}/images/kof.jpg)

2016年11月11日と12日の両日、KOFー関西オープンフォーラムに出展しました。
訪問者もほとんど切れることなく会場を賑わし、Xoxzoのサービスに興味を持った様々な方とお話をすることができて、とても充実した2日間となりました。

![KOF関西にてXoxzoのブース]({filename}/images/kof-booth.jpg)

![KOF関西にてXoxzoの野中がLTを行う]({filename}/images/kof-akira-lt.jpg)

頂いたご質問やご要望は、今後の我々の進む道にも活かされて行くことと思います。
ご多忙の中、ご来場いただき、弊社ブースをご訪問いただいた方々、また、特設ステージでの講演にご参加いただいた皆様、誠にありがとうございました。今後ともどうぞよろしくお願いします。

